package com.example.AdatbTudasbazis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdatbTudasbazisApplicationTests {

	@Test
	void contextLoads() {
	}

}
